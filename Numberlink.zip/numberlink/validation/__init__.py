from .validator import validate_puzzle
